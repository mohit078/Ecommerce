export class Global {
    
    //For API Base Path
    public static BASE_API_PATH = "http://sahosoftweb.com/api/";

    //for image path
    public static BASE_IMAGES_PATH = '';
}
